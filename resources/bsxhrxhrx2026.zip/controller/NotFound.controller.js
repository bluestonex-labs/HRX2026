sap.ui.define(["sap/ui/core/mvc/Controller"],function(n){"use strict";return n.extend("bsx.hrx.hrx2026.controller.NotFound",{onInit:function(){}})});
//# sourceMappingURL=NotFound.controller.js.map